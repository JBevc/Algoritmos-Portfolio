package com.example;

public class Rectangle {
  public int width;
  public int height;

  public int area() {
    return (width*height)/2;
  }
  
}
