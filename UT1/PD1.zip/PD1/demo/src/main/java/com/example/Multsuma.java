package com.example;

public class Multsuma {
    public static void main(String[] args) {
        multsuma(1.0, 2.0, 3.0);
    }

    public static void multsuma(double a, double b, double c) {
        double resultado = a*b + c;
        System.out.println(resultado);

    }
}