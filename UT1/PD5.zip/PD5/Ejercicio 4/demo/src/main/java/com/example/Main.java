package com.example;

public class Main {
    public static void main(String[] args) {
        // EJERCICIO 4
        String[] myFloatArray = {"13.4", "66.1"};
        
        ValueOfDemo.metodoValueOfDemo(myFloatArray);
        
        // La salida es 
        // a + b = 79.5
        // a - b = -52.699997
        // a * b = 885.7399
        // a / b = 0.20272315
        // a % b = 13.4

    }
}